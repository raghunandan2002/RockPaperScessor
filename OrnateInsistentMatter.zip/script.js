function myfunc_3() {
  var comp=Math.floor(Math.random() * (3 - 1 + 1)) + 1;

  if (comp==2){
    document.getElementById('print')
				.innerHTML = "You lose";
        var j=j++;
        document.getElementById('computer')
				.innerHTML = j.value;
  }

  else if (comp==3){
    document.getElementById('print')
				.innerHTML = "You Win";
        var i=i++;
        document.getElementById('you')
				.innerHTML = i.value;
  }
  
  else if (comp==1){
    document.getElementById('print')
				.innerHTML = "Draw";
  }
}

function myfunc_4() {
  var comp=Math.floor(Math.random() * (3 - 1 + 1)) + 1;

  if (comp==2){
    document.getElementById('print')
				.innerHTML = "Draw";
  }

  else if (comp==3){
    document.getElementById('print')
				.innerHTML = "You lose";
        var j=j++;
        document.getElementById('computer')
				.innerHTML = j.value;
  }
  else if (comp==1){
    document.getElementById('print')
				.innerHTML = "You Win";
        var i=i++;
        document.getElementById('you')
				.innerHTML = i.value;
  }
}

function myfunc_5() {
  var comp=Math.floor(Math.random() * (3 - 1 + 1)) + 1;

  if (comp==2){
    document.getElementById('print')
				.innerHTML = "You win";
        var i=i++;
        document.getElementById('you')
				.innerHTML = i.value;
  }

  else if (comp==3){
    document.getElementById('print')
				.innerHTML = "Draw";
  }
  else if (comp==1){
    document.getElementById('print')
				.innerHTML = "You lose";
        var j=j++;
    document.getElementById('computer')
				.innerHTML = j.value;
  }
}

function myfunc_2() {
	location.reload();
}